﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gameshop_AdoNet.Db
{
	public class Kompanija_Crud
	{
		public List<Company> GetAll()
		{
			return null;
		}
	}
}
